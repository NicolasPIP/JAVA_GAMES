/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author EtecJa
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random generator = new Random();
        int [] Personagens = {15, 13, 12, 14, 11};
        int [] numbers = {7, 5, 10, 2, 4, 1, 3, 8, 6, 9};
        String Persona1 = "", Persona2 = "";
        int perso_computador = 0;
        int num_computador = 0;
        int pontos_J = 0, pontos_C = 0;
        int soma_J =0, soma_C = 0;
        int embaralhador = 0;
        int troca = 0;
        JOptionPane.showMessageDialog(null, "===================================== \n Olá, Bem vindo ao COMBINAÇÃO PERFEITA \n =====================================");
        for(int c = 0; c < 4; c++){
            //Embaralhando
            embaralhador = generator.nextInt(11) + 0;
            
            //Embaralhando os Personagens
            for(int i = 0; i < embaralhador; i++){
            troca = Personagens[0];
            Personagens[0] =Personagens[4];
            Personagens[4] = troca;
            
            troca = Personagens[2];
            Personagens[2] = Personagens[4];
            Personagens[4] = troca;
            
            troca = Personagens[1];
            Personagens[1] = Personagens[3];
            Personagens[3] = troca;
            
            }
            
            //Embaralhando as cartas de numeros
            for(int i = 0; i < embaralhador; i++){
            troca = numbers[0];
            numbers[0] = numbers[9];
            numbers[9] = troca;
            
            troca = numbers[1];
            numbers[1] = numbers[9];
            numbers[9] = troca;
            
            troca = numbers[2];
            numbers[2] = numbers[8];
            numbers[8] = troca;
            
            troca = numbers[3];
            numbers[3] = numbers[9];
            numbers[9] = troca;
            
            troca = numbers[4];
            numbers[4] = numbers[8];
            numbers[8] = troca;
            
            troca = numbers[5];
            numbers[5] = numbers[6];
            numbers[6] = troca;
            
            troca = numbers[3];
            numbers[3] = numbers[9];
            numbers[9] = troca;
        
            }
            
            //Escolhendo Aleatóriamente valores para as cartas do Computador
            perso_computador = generator.nextInt(4) + 0;
            num_computador = generator.nextInt(10) + 0;
            
            //Somando os valores do Computador
            soma_C = Personagens[perso_computador] + numbers[num_computador];
            
            //Mensagem
            JOptionPane.showMessageDialog(null, "Após muito embaralhar suas cartas foram escolhidas");
            
            //Escolhendo Aleatóriamente valores para as cartas do Jogador
            String x = JOptionPane.showInputDialog(null, "Escolha uma em 5 cartas : ");
            int escolha = Integer.parseInt(x) - 1;
            while(escolha < 0 || escolha > 4 ){
                x = JOptionPane.showInputDialog(null, "Por favor, escolha uma em 5 cartas : ");
                escolha = Integer.parseInt(x) - 1;
            }
            x = JOptionPane.showInputDialog(null, "Escolha uma em 10 cartas : ");
            int escolha2 = Integer.parseInt(x) - 1;
            while(escolha2 < 0 || escolha2 > 9 ){
                x = JOptionPane.showInputDialog(null, "Por favor, escolha uma em 10 cartas : ");
                escolha2 = Integer.parseInt(x) - 1;
            }
            
            //Somando os valores
            soma_J = Personagens[escolha] + numbers[escolha2];
            
            //Personagem Computador
            if(Personagens[perso_computador] == 11){
                Persona1 = "Bardo";
            }
            else if(Personagens[perso_computador] == 12){
                Persona1 = "Coringa";
            }
            else if(Personagens[perso_computador] == 13){
                Persona1 = "Cavaleiro";
            }
            else if(Personagens[perso_computador] == 14){
                Persona1 = "Rainha";
            }
            else{
                Persona1 = "Rei";
            }
            
            //Personagem Jogador
            if(Personagens[escolha] == 11){
                Persona2 = "Bardo";
            }
            else if(Personagens[escolha] == 12){
                Persona2 = "Coringa";
            }
            else if(Personagens[escolha] == 13){
                Persona2 = "Cavaleiro";
            }
            else if(Personagens[escolha] == 14){
                Persona2 = "Rainha";
            }
            else{
                Persona2 = "Rei";
            }
            
            //Informando ao jogador as cartas sorteadas
            
            JOptionPane.showMessageDialog(null, "O Computador recebeu " + Persona1 + " como personagem, sua força é " + Personagens[perso_computador] + "\n E seu número foi " + numbers[num_computador]);
            JOptionPane.showMessageDialog(null, "O Jogador recebeu " + Persona2 + " como personagem, sua força é " + Personagens[escolha] + "\n E seu número foi " + numbers[escolha2]);
            if(soma_J > soma_C){
                pontos_J ++;
                //Coloca a mensagem que o Jogador Ganhou
                JOptionPane.showMessageDialog(null, "Parabens jogador você conseguiu a combinação de maior força, O ROUND " + (c+1) + " é seu");
            
            }
            else if(soma_C > soma_J){
                pontos_C ++;
                //Coloca a mensagem que o Computador Ganhou
                JOptionPane.showMessageDialog(null, "O Computador conseguiu a combinação de maior força, O ROUND " + (c+1) + " vai para o computador");
            
            }
            else{
                //Fale Empate
                JOptionPane.showMessageDialog(null, "As combinações se equiparam em força, que duelo!!!,  O ROUND " + (c+1) + " deu empate");
            
            }
        
        }
        JOptionPane.showMessageDialog(null, "O duelo terminou e o placar ficou\n" + pontos_C + "Computador\n" + pontos_J + "Jogador");
        if(pontos_C > pontos_J){
            JOptionPane.showMessageDialog(null, "Você perdeu, tende de novo =(");
        
        }
        else if(pontos_C < pontos_J){
            JOptionPane.showMessageDialog(null, "Você ganhou parabens, vamos jogar de novo =)");
        }
         
    }
    
}
